'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { fmt } from '../lib/data';

const BAL = { EUR: [12480.5, '€'], USD: [4210, '$'], GBP: [2095.75, '£'] };
const MSG = [
  ['↓', 'Stipendio ricevuto', '+ 2.350,00 € · adesso'],
  ['↑', 'Bonifico a Lucia', '− 120,00 € · 2 secondi'],
  ['$', 'Pagamento a New York', '− 38,40 $ · tasso reale'],
  ['↓', 'Rimborso ricevuto', '+ 64,90 € · oggi'],
];
const reduced = () => window.matchMedia('(prefers-reduced-motion:reduce)').matches;

export default function Hero() {
  const heroRef = useRef(null);
  const [cur, setCur] = useState('EUR');
  const [val, setVal] = useState(BAL.EUR[0]);
  const valRef = useRef(BAL.EUR[0]);
  const [mi, setMi] = useState(0);
  const [fade, setFade] = useState(false);
  const [spin, setSpin] = useState(false);

  // saldo animato quando cambia valuta
  useEffect(() => {
    const target = BAL[cur][0];
    const start = valRef.current;
    const t0 = performance.now();
    const skip = reduced();
    let raf;
    const step = (n) => {
      const p = skip ? 1 : Math.min((n - t0) / 450, 1);
      const v = start + (target - start) * (1 - Math.pow(1 - p, 3));
      valRef.current = v;
      setVal(v);
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [cur]);

  // notifiche che ruotano
  useEffect(() => {
    if (reduced()) return;
    let timer;
    const id = setInterval(() => {
      setFade(true);
      timer = setTimeout(() => {
        setMi((m) => (m + 1) % MSG.length);
        setFade(false);
      }, 300);
    }, 3600);
    return () => {
      clearInterval(id);
      clearTimeout(timer);
    };
  }, []);

  const onMove = (e) => {
    if (reduced() || !heroRef.current) return;
    const b = heroRef.current.getBoundingClientRect();
    const x = (e.clientX - b.left) / b.width - 0.5;
    const y = (e.clientY - b.top) / b.height - 0.5;
    heroRef.current.querySelectorAll('[data-d]').forEach((el) => {
      const d = Number(el.dataset.d);
      el.style.setProperty('--x', x * d + 'px');
      el.style.setProperty('--y', y * d + 'px');
    });
  };

  const m = MSG[mi];

  return (
    <div className="wrap hero" id="hero" ref={heroRef} onPointerMove={onMove}>
      <div className="hl">
        <h1>
          <span>Il tuo</span>
          <span className="i1">denaro</span>
          <span className="i2">non ha</span>
          <span className="i3">confini</span>
        </h1>
        <p>Conto, carte, prestiti e investimenti in un’unica app. Muovi i soldi in 40 valute con tariffe trasparenti.</p>
        <div className="cta">
          <Link className="btn p" href="/#cambio">Apri un conto</Link>
          <Link className="tl" href="/#cambio">Invia denaro ora</Link>
        </div>
      </div>
      <div className="stage">
        <Image
          className="blob"
          src="/img/hero.webp"
          width={900}
          height={900}
          alt="Globo indigo in plastilina con monete e un aeroplanino di carta in orbita"
          priority
          unoptimized
          data-d="-8"
        />
        <button className={`stick${spin ? ' sp' : ''}`} onClick={() => setSpin(!spin)} aria-label="Canone zero">
          0 € canone
        </button>
        <div className="coin c1" data-d="26">€</div>
        <div className="coin c2" data-d="-34">$</div>
        <div className="fc bal" data-d="18" style={{ '--r': '-4deg' }}>
          <small>Saldo totale</small>
          <b>{fmt(val, 2)} {BAL[cur][1]}</b>
          <div className="chips">
            {Object.keys(BAL).map((c) => (
              <button key={c} aria-pressed={c === cur} onClick={() => setCur(c)}>{c}</button>
            ))}
          </div>
        </div>
        <div className="fc toast" data-d="-22" style={{ '--r': '3deg' }}>
          <i>{m[0]}</i>
          <div style={{ opacity: fade ? 0 : 1 }}><b>{m[1]}</b>{m[2]}</div>
        </div>
      </div>
    </div>
  );
}
