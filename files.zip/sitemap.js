const site = process.env.NEXT_PUBLIC_SITE_URL || 'https://www.tuodominio.it';

export default function sitemap() {
  return ['', '/privacy', '/contatti'].map((p) => ({ url: `${site}${p}` }));
}
