'use client';

import Link from 'next/link';
import { useState } from 'react';
import { RATES, fmt } from '../lib/data';

export default function Converter() {
  const [amt, setAmt] = useState('1000');
  const [from, setFrom] = useState('EUR');
  const [to, setTo] = useState('USD');
  const [flip, setFlip] = useState(false);
  const codes = Object.keys(RATES);

  const v = parseFloat(amt) || 0;
  const eur = v / RATES[from];
  const cost = eur * 0.004 + 0.5;
  const net = (eur - cost) * RATES[to];

  return (
    <section id="cambio" className="dk">
      <div className="wrap">
        <div>
          <h2>Invia denaro all’estero</h2>
          <p>Scegli importo e valuta: vedi subito quanto arriva e quanto paghi. Nessuna sorpresa a fine operazione.</p>
        </div>
        <div className="calc">
          <div className="row">
            <div>
              <label htmlFor="amt">Tu invii</label>
              <input id="amt" type="number" inputMode="decimal" min="1" value={amt} onChange={(e) => setAmt(e.target.value)} />
            </div>
            <div>
              <label htmlFor="from">Da</label>
              <select id="from" value={from} onChange={(e) => setFrom(e.target.value)}>
                {codes.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <button
            className="swap"
            aria-label="Inverti valute"
            style={{ transform: flip ? 'rotate(180deg)' : undefined }}
            onClick={() => { setFrom(to); setTo(from); setFlip(!flip); }}
          >
            ⇅
          </button>
          <div className="row">
            <div>
              <label htmlFor="out">Il destinatario riceve</label>
              <input id="out" type="text" readOnly value={`${fmt(net, 2)} ${to}`} />
            </div>
            <div>
              <label htmlFor="to">A</label>
              <select id="to" value={to} onChange={(e) => setTo(e.target.value)}>
                {codes.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <p className="res">
            Commissione stimata <b>{fmt(cost * RATES[from], 2)} {from}</b>
            <span>1 {from} = {(RATES[to] / RATES[from]).toFixed(4)} {to}. </span> Tassi dimostrativi, non vincolanti.
          </p>
          <Link className="btn p" href="/#top">Continua</Link>
        </div>
      </div>
    </section>
  );
}
