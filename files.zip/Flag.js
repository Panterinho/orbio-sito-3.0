const r = (x, y, w, h, f) => <rect x={x} y={y} width={w} height={h} fill={f} />;

export default function Flag({ code }) {
  let s = null;
  switch (code) {
    case 'IT':
      s = <>{r(0, 0, 13.4, 40, '#009246')}{r(13.3, 0, 13.4, 40, '#fff')}{r(26.6, 0, 13.4, 40, '#ce2b37')}</>;
      break;
    case 'DE':
      s = <>{r(0, 0, 40, 13.4, '#000')}{r(0, 13.3, 40, 13.4, '#dd0000')}{r(0, 26.6, 40, 13.4, '#ffce00')}</>;
      break;
    case 'FR':
      s = <>{r(0, 0, 13.4, 40, '#0055a4')}{r(13.3, 0, 13.4, 40, '#fff')}{r(26.6, 0, 13.4, 40, '#ef4135')}</>;
      break;
    case 'ES':
      s = <>{r(0, 0, 40, 10, '#aa151b')}{r(0, 10, 40, 20, '#f1bf00')}{r(0, 30, 40, 10, '#aa151b')}</>;
      break;
    case 'GB':
      s = (
        <>
          {r(0, 0, 40, 40, '#012169')}
          <path d="M0 0L40 40M40 0L0 40" stroke="#fff" strokeWidth="8" />
          <path d="M0 0L40 40M40 0L0 40" stroke="#c8102e" strokeWidth="3" />
          {r(16, 0, 8, 40, '#fff')}{r(0, 16, 40, 8, '#fff')}
          {r(18, 0, 4, 40, '#c8102e')}{r(0, 18, 40, 4, '#c8102e')}
        </>
      );
      break;
    case 'US':
      s = (
        <>
          {Array.from({ length: 13 }, (_, i) => (
            <rect key={i} x="0" y={(i * 40) / 13} width="40" height={40 / 13 + 0.3} fill={i % 2 ? '#fff' : '#b22234'} />
          ))}
          {r(0, 0, 20, 21.6, '#3c3b6e')}
          {[0, 1, 2].flatMap((i) =>
            [0, 1, 2].map((j) => <circle key={`${i}${j}`} cx={4 + i * 6} cy={4.5 + j * 6.4} r="1.1" fill="#fff" />)
          )}
        </>
      );
      break;
    case 'CH':
      s = <>{r(0, 0, 40, 40, '#d52b1e')}{r(17, 8, 6, 24, '#fff')}{r(8, 17, 24, 6, '#fff')}</>;
      break;
    case 'JP':
      s = <>{r(0, 0, 40, 40, '#fff')}<circle cx="20" cy="20" r="11" fill="#bc002d" /></>;
      break;
    case 'BR':
      s = (
        <>
          {r(0, 0, 40, 40, '#009c3b')}
          <path d="M20 6L36 20L20 34L4 20Z" fill="#ffdf00" />
          <circle cx="20" cy="20" r="7" fill="#002776" />
          <path d="M13.5 19.5Q20 16.5 26.5 21.5" stroke="#fff" strokeWidth="1.4" fill="none" />
        </>
      );
      break;
    case 'IN':
      s = (
        <>
          {r(0, 0, 40, 13.4, '#ff9933')}{r(0, 13.3, 40, 13.4, '#fff')}{r(0, 26.6, 40, 13.4, '#138808')}
          <circle cx="20" cy="20" r="4" fill="none" stroke="#000080" strokeWidth="1.1" />
        </>
      );
      break;
  }
  return (
    <svg viewBox="0 0 40 40" aria-hidden="true" preserveAspectRatio="xMidYMid slice">
      {s}
    </svg>
  );
}
