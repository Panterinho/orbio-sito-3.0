import PageShell from '../../components/PageShell';

export const metadata = {
  title: 'Informativa sulla privacy',
  description: 'Informativa sul trattamento dei dati personali.',
  alternates: { canonical: '/privacy' },
};

export default function Privacy() {
  return (
    <PageShell>
      <h1>Privacy</h1>
      <p className="warn">
        Modello di esempio: sostituisci i dati tra parentesi quadre e fallo verificare da un legale prima della pubblicazione.
      </p>
      <h2>Titolare del trattamento</h2>
      <p>[Ragione sociale], [indirizzo], [email di contatto].</p>
      <h2>Dati raccolti</h2>
      <p>Se usi il modulo contatti raccogliamo nome, indirizzo email e il testo del messaggio.</p>
      <h2>Finalità e base giuridica</h2>
      <p>Usiamo questi dati solo per risponderti (esecuzione di una tua richiesta, art. 6.1.b GDPR).</p>
      <h2>Conservazione</h2>
      <p>Conserviamo i messaggi per [12] mesi, poi li cancelliamo.</p>
      <h2>Destinatari</h2>
      <p>I dati possono essere trattati da fornitori che ci aiutano a gestire il sito: [hosting], [servizio dei moduli].</p>
      <h2>I tuoi diritti</h2>
      <p>
        Puoi chiedere accesso, rettifica, cancellazione, limitazione e portabilità dei dati, e opporti al trattamento,
        scrivendo a [email]. Puoi anche presentare reclamo al Garante per la protezione dei dati personali.
      </p>
      <h2>Cookie e servizi di terze parti</h2>
      <p>
        Il sito non usa cookie di profilazione. Il font Inter è servito dal nostro stesso dominio. [Se aggiungi strumenti di
        statistica, indicalo qui.]
      </p>
    </PageShell>
  );
}
