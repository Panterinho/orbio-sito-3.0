import Link from 'next/link';
import PageShell from '../../components/PageShell';

export const metadata = {
  title: 'Contatti',
  description: 'Contatta il team di Orbio.',
  alternates: { canonical: '/contatti' },
};

export default function Contatti() {
  const action = process.env.NEXT_PUBLIC_FORM_URL || 'https://formspree.io/f/TUO_ID';
  return (
    <PageShell>
      <h1>Scrivici</h1>
      <p>Rispondiamo di solito entro due giorni lavorativi.</p>
      <form action={action} method="post">
        <div>
          <label htmlFor="n">Nome</label>
          <input id="n" name="nome" type="text" required autoComplete="name" />
        </div>
        <div>
          <label htmlFor="e">Email</label>
          <input id="e" name="email" type="email" required autoComplete="email" />
        </div>
        <div>
          <label htmlFor="m">Messaggio</label>
          <textarea id="m" name="messaggio" required />
        </div>
        <input className="hp" type="text" name="_gotcha" tabIndex={-1} autoComplete="off" aria-hidden="true" />
        <p style={{ fontSize: 14, margin: 0 }}>
          Inviando accetti l’<Link href="/privacy">informativa sulla privacy</Link>.
        </p>
        <button className="btn p" type="submit">Invia messaggio</button>
      </form>
    </PageShell>
  );
}
