'use client';

import { useState } from 'react';
import { COUNTRIES, RATES } from '../lib/data';
import Flag from './Flag';

export default function Countries() {
  const [sel, setSel] = useState(0);
  const c = COUNTRIES[sel];
  return (
    <section id="paesi" className="cn">
      <div className="wrap">
        <h2>Dove puoi inviare denaro</h2>
        <p style={{ margin: 0, maxWidth: 520 }}>
          Tocca un paese per vedere tempi e costi. Più di 160 destinazioni; qui le principali.
        </p>
        <div className="pills">
          {COUNTRIES.map((x, i) => (
            <button key={x[0]} aria-pressed={i === sel} onClick={() => setSel(i)}>
              <i><Flag code={x[0]} /></i>
              {x[1]}
            </button>
          ))}
        </div>
        <div className="dt" aria-live="polite">
          <b>{c[1]} · {c[2]}</b>
          1 EUR = {RATES[c[2]].toFixed(2)} {c[2]}. Il denaro arriva {c[3]}. Commissione da 0,50 € + 0,4%.
        </div>
      </div>
    </section>
  );
}
