import Header from './Header';
import Footer from './Footer';

export default function PageShell({ children }) {
  return (
    <div className="pg">
      <Header />
      <main className="page">{children}</main>
      <Footer />
    </div>
  );
}
