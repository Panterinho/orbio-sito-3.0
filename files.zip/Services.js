'use client';

import Image from 'next/image';
import Link from 'next/link';
import { useRef, useState } from 'react';
import { fmt } from '../lib/data';

const TABS = ['Conto', 'Carte', 'Prestiti', 'Investimenti', 'Aziende'];
const COLORS = ['#1a1446', '#2d2a8c', '#d9573a', '#0d7a6b', '#6b3fa0'];
const PLANS = [
  ['9 € / mese', 'Conto, 2 carte e fatture incluse. Ideale per freelance e studi.'],
  ['29 € / mese', 'Pagamenti in blocco, permessi per ruolo e accesso del commercialista.'],
  ['Su misura', 'Integrazione API con il gestionale e un referente dedicato.'],
];
const TEAMS = ['1–5 persone', '6–20', 'Oltre 20'];

function Pic({ src, alt }) {
  return <Image className="pic" src={src} width={760} height={567} alt={alt} unoptimized />;
}

function Conto() {
  const [g, setG] = useState(0);
  return (
    <div role="tabpanel">
      <Pic src="/img/conto.webp" alt="Smartphone in plastilina con carte di conti in più valute" />
      <span className="tag">Conto multivaluta</span>
      <h3>Metti da parte, un tocco alla volta</h3>
      <p>IBAN italiano, bonifici istantanei e salvadanai per ogni obiettivo. Prova: il viaggio è a 800 €.</p>
      <div className="big">{fmt(g)} € <small>di 800 €</small></div>
      <div className="goal"><div style={{ width: `${Math.min(g / 8, 100)}%` }} /></div>
      <button className="btn p" onClick={() => setG(Math.min(g + 50, 800))}>
        {g >= 800 ? 'Obiettivo raggiunto' : 'Aggiungi 50 €'}
      </button>{' '}
      <button className="tl" style={{ border: 0, background: 'none', cursor: 'pointer', fontSize: 16 }} onClick={() => setG(0)}>
        Azzera
      </button>
    </div>
  );
}

function Carte() {
  const [color, setColor] = useState(COLORS[0]);
  const [name, setName] = useState('');
  const card = useRef(null);
  const tilt = (rx, ry) => {
    if (!card.current) return;
    card.current.style.setProperty('--rx', rx + 'deg');
    card.current.style.setProperty('--ry', ry + 'deg');
  };
  const move = (e) => {
    if (!card.current || window.matchMedia('(prefers-reduced-motion:reduce)').matches) return;
    const b = card.current.getBoundingClientRect();
    tilt(-((e.clientY - b.top) / b.height - 0.5) * 24, ((e.clientX - b.left) / b.width - 0.5) * 24);
  };
  return (
    <div role="tabpanel">
      <Pic src="/img/carte.webp" alt="Due carte di pagamento, indigo e corallo, con monete in orbita" />
      <span className="tag">Carte</span>
      <h3>Disegna la tua carta virtuale</h3>
      <div className="cd" onPointerMove={move} onPointerLeave={() => tilt(0, 0)}>
        <div className="card3d" ref={card} style={{ background: color }}>
          <b>Orbio</b>
          <div className="chip"></div>
          <div className="num">•••• •••• •••• 4821</div>
          <div className="nm">{name || 'Il tuo nome'}</div>
        </div>
        <div style={{ flex: 1, minWidth: 190 }}>
          <label htmlFor="nm" style={{ fontWeight: 500, color: 'var(--head)', fontSize: 15 }}>Nome sulla carta</label>
          <input id="nm" type="text" maxLength={22} placeholder="Il tuo nome" value={name} onChange={(e) => setName(e.target.value)} />
          <div className="sw">
            {COLORS.map((c, i) => (
              <button key={c} style={{ background: c }} aria-label={`Colore ${i + 1}`} aria-pressed={c === color} onClick={() => setColor(c)} />
            ))}
          </div>
          <Link className="btn p" href="/#cambio">Ordina la carta</Link>
        </div>
      </div>
      <p className="note">Muovi il mouse sulla carta per inclinarla. Prelievi gratuiti fino a un limite mensile.</p>
    </div>
  );
}

function Prestiti() {
  const [amount, setAmount] = useState(10000);
  const [months, setMonths] = useState(36);
  const r = 0.069 / 12;
  const rata = (amount * r) / (1 - Math.pow(1 + r, -months));
  return (
    <div role="tabpanel">
      <Pic src="/img/prestiti.webp" alt="Chiave e casetta in plastilina accanto a una pila di monete" />
      <span className="tag">Prestiti</span>
      <h3>Quanto ti costa davvero?</h3>
      <div className="ctl">
        <label>Importo <span>{fmt(amount)} €</span></label>
        <input type="range" min={1000} max={50000} step={500} value={amount} aria-label="Importo" onChange={(e) => setAmount(+e.target.value)} />
        <label>Durata <span>{months} mesi</span></label>
        <input type="range" min={6} max={84} step={6} value={months} aria-label="Durata in mesi" onChange={(e) => setMonths(+e.target.value)} />
      </div>
      <div className="big">{fmt(rata, 2)} € <small>al mese</small></div>
      <p className="note">Totale da restituire: {fmt(rata * months)} € (interessi: {fmt(rata * months - amount)} €)</p>
      <p className="note">Simulazione dimostrativa con tasso fisso al 6,9% annuo, non vincolante.</p>
    </div>
  );
}

function Investimenti() {
  const [m, setM] = useState(150);
  const [y, setY] = useState(15);
  const i = 0.04 / 12;
  const a = [];
  const b = [];
  for (let k = 0; k <= y; k++) {
    const n = k * 12;
    a.push((m * (Math.pow(1 + i, n) - 1)) / i);
    b.push(m * n);
  }
  const mx = a[y] || 1;
  const H = 130;
  const pt = (arr) => arr.map((v, k) => `${((k / y) * 400).toFixed(1)},${(H + 5 - (v / mx) * H).toFixed(1)}`).join(' ');
  return (
    <div role="tabpanel">
      <Pic src="/img/investimenti.webp" alt="Piantina che cresce da una pila di monete con una freccia in salita" />
      <span className="tag">Investimenti</span>
      <h3>Guarda crescere i risparmi</h3>
      <div className="ctl">
        <label>Versamento mensile <span>{fmt(m)} €</span></label>
        <input type="range" min={10} max={1000} step={10} value={m} aria-label="Versamento mensile" onChange={(e) => setM(+e.target.value)} />
        <label>Anni <span>{y}</span></label>
        <input type="range" min={1} max={30} value={y} aria-label="Anni" onChange={(e) => setY(+e.target.value)} />
      </div>
      <svg className="ch" viewBox="0 0 400 140" preserveAspectRatio="none" aria-hidden="true">
        <polyline points={pt(b)} fill="none" stroke="#86868f" strokeWidth="3" strokeDasharray="6 6" />
        <polyline points={pt(a)} fill="none" stroke="#ff8f6b" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
      <div className="big">{fmt(a[y])} € <small>stimati, di cui {fmt(b[y])} € versati da te</small></div>
      <p className="note">Esempio con rendimento ipotetico del 4% annuo. I rendimenti non sono garantiti e il capitale può diminuire.</p>
    </div>
  );
}

function Aziende() {
  const [t, setT] = useState(0);
  return (
    <div role="tabpanel">
      <Pic src="/img/aziende.webp" alt="Negozio con tenda corallo, valigetta e fatture" />
      <span className="tag">Aziende</span>
      <h3>Un conto che cresce con il tuo team</h3>
      <div className="chips" style={{ margin: '16px 0' }}>
        {TEAMS.map((x, i) => (
          <button key={x} aria-pressed={i === t} onClick={() => setT(i)}>{x}</button>
        ))}
      </div>
      <div className="big">{PLANS[t][0]}</div>
      <p style={{ marginTop: 12 }}>{PLANS[t][1]}</p>
      <Link className="btn p" href="/#cambio">Apri un conto business</Link>
    </div>
  );
}

const PANELS = [Conto, Carte, Prestiti, Investimenti, Aziende];

export default function Services() {
  const [tab, setTab] = useState(0);
  const Panel = PANELS[tab];
  return (
    <section id="servizi" className="wrap svc">
      <h2>Una banca intera, da provare con le tue mani</h2>
      <div className="menu" role="tablist" aria-label="Servizi">
        {TABS.map((t, i) => (
          <button key={t} role="tab" aria-selected={i === tab} onClick={() => setTab(i)}>{t}</button>
        ))}
      </div>
      <div className="sheet"><Panel /></div>
    </section>
  );
}
