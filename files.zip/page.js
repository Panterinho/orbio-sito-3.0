import Header from '../components/Header';
import Footer from '../components/Footer';
import Hero from '../components/Hero';
import Ticker from '../components/Ticker';
import Services from '../components/Services';
import Converter from '../components/Converter';
import Countries from '../components/Countries';

export default function Home() {
  return (
    <>
      <Header />
      <main id="top">
        <Hero />
        <Ticker />
        <Services />
        <Converter />
        <Countries />
      </main>
      <Footer />
      <aside className="qr" aria-label="Scarica l’app">
        <div>QR code</div>
        <span>Scarica l’app Orbio</span>
      </aside>
    </>
  );
}
