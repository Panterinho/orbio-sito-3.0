export const RATES = { EUR: 1, USD: 1.08, GBP: 0.85, CHF: 0.96, JPY: 162, BRL: 5.9, INR: 90 };

export const COUNTRIES = [
  ['IT', 'Italia', 'EUR', 'pochi secondi'],
  ['DE', 'Germania', 'EUR', 'pochi secondi'],
  ['FR', 'Francia', 'EUR', 'pochi secondi'],
  ['ES', 'Spagna', 'EUR', 'pochi secondi'],
  ['GB', 'Regno Unito', 'GBP', 'in meno di un’ora'],
  ['US', 'Stati Uniti', 'USD', 'entro 1 ora'],
  ['CH', 'Svizzera', 'CHF', 'in meno di un’ora'],
  ['JP', 'Giappone', 'JPY', 'entro 1 giorno'],
  ['BR', 'Brasile', 'BRL', 'entro 1 giorno'],
  ['IN', 'India', 'INR', 'entro 1 giorno'],
];

export const fmt = (n, d = 0) =>
  n.toLocaleString('it-IT', { maximumFractionDigits: d, minimumFractionDigits: d });
