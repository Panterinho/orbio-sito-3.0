import Link from 'next/link';
import PageShell from '../components/PageShell';

export const metadata = { title: 'Pagina non trovata' };

export default function NotFound() {
  return (
    <PageShell>
      <h1>Pagina non trovata</h1>
      <p>Il link che hai seguito non esiste più o è stato spostato.</p>
      <p><Link className="btn p" href="/">Torna alla home</Link></p>
    </PageShell>
  );
}
