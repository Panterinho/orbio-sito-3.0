import Link from 'next/link';

export default function Footer() {
  return (
    <footer>
      <div className="wrap">
        <div className="cols">
          <div>
            <div className="logo" style={{ color: '#fff', marginBottom: 12 }}><i></i>Orbio</div>
            <p style={{ margin: 0, maxWidth: 320 }}>La banca per chi vive, lavora e viaggia oltre i confini.</p>
          </div>
          <div>
            <h4>Prodotti</h4>
            <Link href="/#servizi">Conto</Link><Link href="/#servizi">Carte</Link>
            <Link href="/#servizi">Prestiti</Link><Link href="/#servizi">Investimenti</Link>
          </div>
          <div>
            <h4>Azienda</h4>
            <Link href="/#top">Chi siamo</Link><Link href="/#top">Lavora con noi</Link><Link href="/#top">Stampa</Link>
          </div>
          <div>
            <h4>Assistenza</h4>
            <Link href="/contatti">Centro aiuto</Link><Link href="/contatti">Contatti</Link><Link href="/privacy">Privacy</Link>
          </div>
        </div>
        <small>
          Orbio è un marchio fittizio creato a scopo dimostrativo. Tassi, importi e condizioni mostrati sono esempi e non costituiscono un’offerta.
        </small>
      </div>
    </footer>
  );
}
