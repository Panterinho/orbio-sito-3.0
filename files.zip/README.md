# Orbio – Next.js

Progetto Next.js (App Router) pronto per Vercel. Non richiede configurazione particolare.

## Provarlo in locale
```bash
npm install
npm run dev      # http://localhost:3000
```

## Pubblicare su Vercel
1. Carica la cartella su un repository GitHub (la cartella del progetto deve contenere `package.json` direttamente nella radice).
2. Su Vercel: **Add New → Project**, scegli il repository. Il framework (Next.js) viene riconosciuto da solo.
3. In **Settings → Environment Variables** aggiungi (vedi `.env.example`):
   - `NEXT_PUBLIC_SITE_URL` = il tuo dominio, es. `https://www.tuodominio.it`
   - `NEXT_PUBLIC_FORM_URL` = l’indirizzo del tuo servizio di moduli (es. Formspree)
4. Deploy. Poi collega il dominio da **Settings → Domains**.

In alternativa, con la CLI: `npm i -g vercel` e poi `vercel` dalla cartella del progetto.

## Struttura
- `app/` pagine (`/`, `/privacy`, `/contatti`, 404), `layout.js`, `globals.css`, `robots.js`, `sitemap.js`, `icon.svg`
- `components/` Header, Footer, Hero, Services, Converter, Countries, Flag, Ticker
- `lib/data.js` tassi e paesi dimostrativi
- `public/img/` immagini (.webp) e anteprima social

## Da fare prima di andare online
- Compila la pagina privacy (dati tra parentesi quadre) e fai verificare il testo da un legale.
- Pulsanti "Accedi", "Apri un conto" e "Continua": collegali a pagine reali o rimuovili.
- Sostituisci il riquadro QR in `app/page.js` o eliminalo.
- Tassi, prestiti e investimenti sono valori dimostrativi.
- Il font Inter è caricato con `next/font`, quindi viene servito dal tuo dominio (nessuna richiesta a Google dai visitatori).
