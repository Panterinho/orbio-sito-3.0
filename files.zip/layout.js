import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '900'],
  display: 'swap',
  variable: '--font-inter',
});

const site = process.env.NEXT_PUBLIC_SITE_URL || 'https://www.tuodominio.it';
const description =
  'Conto, carte, prestiti e investimenti in un’unica app. Invia denaro in 40 valute con tariffe trasparenti.';

export const metadata = {
  metadataBase: new URL(site),
  title: { default: 'Orbio – La banca senza confini', template: '%s – Orbio' },
  description,
  alternates: { canonical: '/' },
  openGraph: {
    type: 'website',
    locale: 'it_IT',
    title: 'Orbio – La banca senza confini',
    description,
    url: '/',
    images: ['/img/og-image.jpg'],
  },
  twitter: { card: 'summary_large_image' },
};

export const viewport = {
  width: 'device-width',
  initialScale: 1,
  viewportFit: 'cover',
  themeColor: '#1a1446',
};

export default function RootLayout({ children }) {
  return (
    <html lang="it" className={inter.variable}>
      <body>{children}</body>
    </html>
  );
}
