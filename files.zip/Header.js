import Link from 'next/link';

export default function Header() {
  return (
    <header>
      <div className="wrap">
        <Link className="logo" href="/"><i></i>Orbio</Link>
        <nav className="seg" aria-label="Sezioni">
          <Link className="on" href="/#top">Privati</Link>
          <Link href="/#servizi">Servizi</Link>
          <Link href="/#paesi">Paesi</Link>
        </nav>
        <div className="right">
          <Link className="tl" href="/contatti">Aiuto</Link>
          <Link className="btn o" href="/#top">Accedi</Link>
          <Link className="btn p" href="/#cambio" style={{ padding: '8px 18px' }}>Apri un conto</Link>
        </div>
      </div>
    </header>
  );
}
