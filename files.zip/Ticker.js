import { RATES } from '../lib/data';

export default function Ticker() {
  const items = [];
  for (let k = 0; k < 4; k++) {
    Object.entries(RATES).forEach(([c, v]) => {
      if (c !== 'EUR') items.push({ key: `${k}-${c}`, c, v });
    });
  }
  return (
    <div className="tick" aria-hidden="true">
      <div>
        {items.map(({ key, c, v }) => (
          <span key={key}>EUR/{c}<em>{v.toFixed(2)}</em></span>
        ))}
      </div>
    </div>
  );
}
